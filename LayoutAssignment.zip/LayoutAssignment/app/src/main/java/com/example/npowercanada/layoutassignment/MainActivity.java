package com.example.npowercanada.layoutassignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void loadFrameLayoutActivity(View view) {
        Intent i = new Intent(MainActivity.this, FrameLayoutActivity.class);
        startActivity(i); //this will excute my intent
    }

    public void loadTableLayoutActivity(View view) {
        Intent i = new Intent(MainActivity.this, TableLayoutActivity.class);
        startActivity(i); //this will excute my intent
    }

    public void loadRelativeLayoutActivity(View view) {
        Intent i = new Intent(MainActivity.this, RelativeLayoutActivity.class);
        startActivity(i); //this will excute my intent
    }

    public void loadLinearLayoutActivity(View view) {
        Intent i = new Intent(MainActivity.this, LinearLayoutActivity.class);
        startActivity(i); //this will excute my intent
    }

    public void loadGridLayoutActivity(View view) {
        Intent i = new Intent(MainActivity.this, GridLayoutActivity.class);
        startActivity(i); //this will excute my intent
    }


}

