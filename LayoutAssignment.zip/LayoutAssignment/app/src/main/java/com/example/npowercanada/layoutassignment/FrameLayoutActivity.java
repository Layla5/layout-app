package com.example.npowercanada.layoutassignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;


public class FrameLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frame_layout);
    }

    public void loadMainActivity(View view){
        Intent i = new Intent (FrameLayoutActivity.this, MainActivity.class);
        startActivity(i);
    }
}
